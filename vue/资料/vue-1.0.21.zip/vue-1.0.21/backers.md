# Backers

You can join them in supporting  Vue.js development by [pledging on Patreon](https://www.patreon.com/evanyou).

### $2000

<a href="https://strikingly.com/s/careers?utm_source=v">
  <img width="500px" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/strikingly.png">
</a>

---

### $250

<a href="https://laravel.com">
  <img width="300px" src="http://blog.legacyteam.info/wp-content/uploads/2014/10/laravel-logo-white.png">
</a>

---

### $100

<a href="http://tighten.co/">
  <img width="200px" src="http://i.imgur.com/T7fQYLT.png">
</a>

<a href="http://invoicemachine.com/">
  <img width="200px" src="http://assets.invoicemachine.com/images/flat_logo.png">
</a>

---

### $50

- James Kyle
- Blake Newman
- Lee Smith
- Adam Dorsey

---

### $10

- Sylvain Pollet-Villard
- Luca Borghini
- Kazuya Kawaguchi
- Keisuke Kita
- Anirudh Sanjeev
- Guido Bertolino
- Fábio Vedovelli
- Jack Barham
- Stephane Demoote
- Paul R. Dillinger
- Sean Washington
- Alun Davey
- Eduardo Kyvenko
- Thijs de Maa
- Joris Noordermeer
- Niklas Lifors
- An Phan
- Richard Wyke
- Roman Kuba
- Tom Conlon
- Matt Pickle
- Simon East
- Bill Columbia
- Hayden Bickerton
- Henry Zhu
- John Smith
